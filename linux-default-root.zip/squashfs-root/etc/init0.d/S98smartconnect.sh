#!/bin/sh
echo [$0]: $1 ... > /dev/console
service SMARTCONNECT start

exit 0
