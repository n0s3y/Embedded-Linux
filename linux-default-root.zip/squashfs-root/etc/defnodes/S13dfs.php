<?
set("/runtime/device/na", "0");
set("/runtime/device/eu","0");
?>
