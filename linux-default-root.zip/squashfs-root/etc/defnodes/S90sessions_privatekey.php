<?
	set("/runtime/device/sessions_privatekey", 1);
?>
