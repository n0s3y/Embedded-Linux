<?
include "/htdocs/phplib/trace.php";
include "/etc/services/IP6TABLES/ip6tlan.php";
IP6TLAN_build_command("LAN-3");
?>
