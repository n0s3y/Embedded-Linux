<?
include "/etc/services/PHYINF/phywifi.php";
phyinf_active("BAND24G-1.1");
?>
