<?
include "/etc/services/PHYINF/phywifi.php";
wificonfig("BAND5G-1.1");
?>
