<?
include "/etc/services/PHYINF/phywifi.php";
wificonfig("WIFISTA-1.2");
?>

