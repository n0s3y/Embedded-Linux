#!/bin/sh
mkdir -p /dev/pts
mount -t devpts devpts /dev/pts
