#!/bin/sh
# This helper script is only called when "MAXRETRY" occured.
# We do nothing for "MAXRETRY" case, now.
echo [$0]: $1 $2 $3 (do nothing)... > /dev/console
